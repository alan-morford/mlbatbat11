var localExtras = {
		leftnav : [
	          {
	        	  "title": "Scoreboard",
	        	  "view":"Scoreboard",
	        	  "clicked": "true"
	        		  
	          },
	          {
	        	  "title": "News",
	        	  "view":"News"
	          } 
	          ]
};