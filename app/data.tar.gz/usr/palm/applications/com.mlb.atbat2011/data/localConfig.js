var localConfig = {
  "season":2011
  ,"firstAllowedDay":[2011,3,31]
  ,"lastAllowedDay":[2011,11,15]
  ,"suggestedDay":[2011,3,31]
  ,"openingDay":[2011,3,31]
  ,"videoPlaybackScenarios":{
    "high":"FLASH_1200K_640X360",
    "low":"FLASH_1200K_640X360",
	"condensedGames":{
		"high" : "FLASH_1200K_640X360",
		"low" : "FLASH_1200K_640X360"
	}
  }
  ,"audioPlaybackScenarios":{
    "high":"AUDIO_SHOUTCAST_32K",
    "low":"AUDIO_SHOUTCAST_32K" 
  }
  ,"audio": {
    "platform":"PALM",
    "sku": "PALMATBAT2011"
  }
  ,"gamedayUrl": {
    "PROD":"http://wapc.mlb.com/gd3/apps/native/palm.jsp?cacheId=20110727",
    "QA":"http://wapqa.mlb.com/gd3/apps/native/palm.jsp?cacheId=20110727"
  },
	"scoreboardUrls":{
		"template" : {
			"PROD" : "http://wapc.mlb.com/webos/scoreboard_tpl.html",
			"QA" : "http://wapqa.mlb.com/webos/scoreboard_tpl.html"
		},
		"data": {
			"PROD" : "http://wapc.mlb.com/gdcross/components/game/mlb/year_{$YYYY}/month_{$MM}/day_{$DD}/master_scoreboard.json",
			"QA" : "http://wapqa.mlb.com/gdcross/components/game/mlb/year_{$YYYY}/month_{$MM}/day_{$DD}/master_scoreboard.json"
		}
	}
};


