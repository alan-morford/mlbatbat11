enyo
		.kind( {
			name : "mlb.GamedayHeader",
			kind : enyo.HFlexBox,
			style : "width:100%; ",
			published : {
				gamedayView : null
			},
			components : [
					{
						kind : enyo.HFlexBox,
						flex : 1
					},
					{
						kind : enyo.HFlexBox,
						flex : 1,
						name : "navButtonGroups",
						style : "height : 32px; width : 100%; margin-top:12px",
						components : [
								{
									kind : "RadioToolButtonGroup",
									name : "liveNav",
									style : "position : relative; left : -115px;",
									components : [
											{
												name : "Gameday",
												value : "game",
												caption : "Gameday",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-first tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Gameday_Box",
												value : "boxscore",
												caption : "Box",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-middle tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Gameday_Summary",
												caption : "Summary",
												value : "scores",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-middle tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Gameday_Video",
												caption : "Video",
												value : "video",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-middle tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Gameday_Field",
												caption : "Field",
												value : "field",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-last tabButton",
												onclick : "buttonClick"
											} ]
								},
								{
									kind : "RadioToolButtonGroup",
									name : "wrapNav",
									style : "position : relative; left : -115px;",
									components : [
											{
												name : "Wrap",
												caption : "Wrap",
												value : "game",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-first tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Wrap_Box",
												caption : "Box",
												value : "boxscore",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-middle tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Wrap_Summary",
												caption : "Summary",
												value : "scores",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-middle tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Wrap_Video",
												caption : "Video",
												value : "video",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-middle tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Wrap_Field",
												caption : "Field",
												value : "field",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-last tabButton",
												onclick : "buttonClick"
											} ]
								},
								{
									kind : "RadioToolButtonGroup",
									name : "previewNav",
									showing : false,
									components : [
											{
												name : "Preview",
												caption : "Preview",
												value : "preview",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-first tabButton",
												onclick : "buttonClick"
											},
											{
												name : "Probables",
												caption : "Probables",
												value : "preview",
												className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-last tabButton",
												onclick : "buttonClick"
											} ]
								} ]
					}, {
						kind : enyo.HFlexBox,
						flex : 1
					} ],
			buttonClick : function(inSender) {
				this.clearControls(inSender);

				this.gamedayView.setView(inSender.getValue());
				return false;
			},
			clearControls : function(inSender) {
				var controls = this.$.liveNav.controls;
				for ( var i = 0, c; c = controls[i]; i++) {
					if (c != inSender)
						c.setDepressed(false);
				}
				if (!inSender)
					controls[0].setDepressed(true);

				controls = this.$.wrapNav.controls;
				for ( var i = 0, c; c = controls[i]; i++) {
					if (c != inSender)
						c.setDepressed(false);
				}
				if (!inSender)
					controls[0].setDepressed(true);

				/*
				 * controls = this.$.previewNav.controls; for (var i=0, c;
				 * c=controls[i]; i++) { if(c!=inSender) c.setDepressed(false); }
				 * if(!inSender) controls[0].setDepressed(true);
				 */

			},

			rendered : function() {

				this.inherited(arguments);
				this.clearControls();
			}

		});

enyo.kind( {
	name : "mlb.GamedayView",
	kind : enyo.VFlexBox,
	flex : 1,
	// style : "width: 418px; background-color: rgba(1,1,1,0.5)",
	published : {
		game : null,
		state : "",
		header : null
	},
	components : [ {
		kind : "Pane",
		name : "panes",
		flex : 1,
		transitionKind : "enyo.transitions.Fade",
		components : [ {
			name : "webview",
			kind : "WebView",
			minFontSize : "0",
			style : "height: 100%; width: 100%"
			
		}, {
			name : "videoView",
			kind : "mlb.VideoView",
			style : "background-color: #E7E7DC"
		} ]
	}
	],

	
	create : function() {
		console.log("CREATED!");
		this.inherited(arguments);

	},
	clearGameView: function() {
		
		this.$.webview.setUrl(getGamedayBaseUrl()+"#stop");
	},

	ready : function() {

	},
	

	setGame : function(gid, state) {
		console.log("*********SETTING GAME*************");
		

		// this.$.panes.selectViewByIndex(0);
		this.state = state;
		this.header = (this.header == null) ? new mlb.GamedayHeader()
				: this.header;

		this.header.gamedayView = this;
		/*(this.header).renderInto(document
				.getElementById(main.$.sliding.$.middleCanonView.$.title.id));*/
		
		this.header.renderInto(document.getElementById("main_sliding_Scoreboard_scoreboardHeader_client"));
		
		this.$.panes.selectViewByIndex(0);

		console.log("CURRENT GAME = " + gid);
		this.game = gid;

		var stateObj = { status_ind : state  };
	
		if ( GameFlags.isBeforeGameStart(stateObj) || GameFlags.isSuspended(stateObj) ) {

			this.setWebViewUrl(this.game, "preview");
			this.setNavView("preview");
			Track("GameDay_Popup_preview");
		} else if(GameFlags.isDuringGame(stateObj)){
			this.setWebViewUrl(this.game, "game");
			this.setNavView("live");
			Track("GameDay_Popup_game");
		}
		else if(GameFlags.isAfterGameEnd(stateObj)) {
			this.setWebViewUrl(this.game, "game");
			this.setNavView("wrap");
		}
		
		console.log('THIS.GAME=' + this.game);
	},
	setView : function(view) {

		console.log("CURRENT GAME = " + this.game);
		Track("GameDay_Popup_" + view);
		//alert("SETVIEW");
		if (view == "video") {
			console.log("VIDEOVIEW");
			this.$.panes.selectViewByIndex(1);
			this.$.videoView.gameId = this.game;
			this.$.videoView.loadVideos();
		} else if (view == "game") {
			this.$.panes.selectViewByIndex(0);
			
			var stateObj = {"status_ind": this.state};
			
			if (GameFlags.isBeforeGameStart(stateObj) || GameFlags.isSuspended(stateObj)) {
			
				this.setWebViewUrl(this.game, "preview");
				this.setNavView("preview");
			} else if(GameFlags.isDuringGame(stateObj)) {
			
				this.setWebViewUrl(this.game, "game");
				this.setNavView("live");
			}
			else {
			
				this.setWebViewUrl(this.game, "game");
				this.setNavView("wrap");
			}
			

		} else {
			this.$.panes.selectViewByIndex(0);
			this.setWebViewUrl(this.game, view);
		}

	},
	setWebViewUrl : function(gid, view) {
		// alert(gid);
		var loc = gid.substring(21, 24);

		this.$.webview.setUrl(getGamedayBaseUrl() + "#gameId=gid_" + this.game
				+ ",view=" + view + ",loc=" + loc);
	},

	setNavView : function(view) {
	
		var navButtonGroups = this.header.$;
		if (view == "preview") {
					// navButtonGroups.previewNav.show();
			navButtonGroups.liveNav.hide();
			navButtonGroups.wrapNav.hide();
		} else if (view == "live") {
			// navButtonGroups.previewNav.hide();
			navButtonGroups.liveNav.show();
			navButtonGroups.wrapNav.hide();
		} else if (view == "wrap") {
			//navButtonGroups.previewNav.hide();
			navButtonGroups.liveNav.hide();
			navButtonGroups.wrapNav.show();
		}
	}

});

function getGamedayBaseUrl() {
	var url = main.config.gamedayUrl.PROD;
	if (env.currentEnv == env.QA) {
		url = main.config.gamedayUrl.QA;
	}
	
	return url;
}

//var GamedayView = new mlb.GamedayView();