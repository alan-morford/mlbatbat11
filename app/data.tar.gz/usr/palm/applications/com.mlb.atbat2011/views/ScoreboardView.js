var Months = [
		"January", "Febuary", "March", "April", "May", "June", "July",
		"August", "September", "October", "November", "December" ], 
	aDay = 86400000, 
	changeScoreboardDate = null, 
	showGameDayAudio = null, 
	displayAudioModal = null, 
	isLoading = false, 
	displayGameDayModal = false, 
	isCreated = false, 
	tenHours = 60000 * 60 * 10;

enyo
		.kind( {
			name : "mlb.ScoreboardView",
			kind : "enyo.VFlexBox",
			flex : 1,
			published : {
				date : null,
				header : null,
				configDates : null,
				isPopupDisplayed : false,
				hidePopups : null
			},
			setGame : function(gid, state) {
				this.$.gamedayView.setGame(gid, state);
			},
			style : "background-color:#e7e7db",
			components : [
			        {kind: "Scrim", flex:1, name : "scrim", onclick: "scrimClick", id: "ScoreboardScrim",
			        	style : "position:absolute;height:768;top:50px;width:1024px;background-color:#333;"
			        		},
					{
						kind : "enyo.VFlexBox",
						flex:1,
						components : [ {
							flex:0,
							name : "scoreboardHeader",
							kind : "mlb.ScoreboardHeader"
							
						}, {
							kind : "Scroller",
							name: "scroller",
							flex:1,
							components : [ {
								name : "scoreboard",
								flex:1,
								allowHtml : true,
								style : "height:100%;width:100%"
							} ]
						},

						{
							flex:0,
							kind : "Toolbar",
							height : "40px",
							components : [ {
								kind : "GrabButton"
							} ]
						}

						]

					},

					{
						kind : "Popup",
						name : "gameday",
						dismissWithClick : false,
						className : "gamedayPopup",
						style : "height:620px;width:420px; border:none; -webkit-border-image:none; -webkit-box-shadow: 0 0 5px #000;",
						onClose : "gamedayClosed",
						components : [ {
							name : "gamedayChrome",
							flex : 1,
							style : "height:618px;width:418px; background-color:#e7e7dc !important;border:1px solid #000;",
							components : [ {
								kind : "mlb.GamedayView",
								name : "gamedayView",
								style : "width:100%; height:100%"
							} ]

						} ]
					},
					{
						kind : "Popup",
						name : "audio",
						dismissWithClick : false,
						className : "audioPopup",
						style : "height:620px;width:430px; border:none; -webkit-border-image:none;",
						components : [ {
							name : "audioChrome",
							flex : 1,
							style : "height:618px;width:428px; background-color:transparent !important;border:none;"
						} ]
					} ],
			gamedayClosed : function() {
				this.$.gamedayView.clearGameView();
			},
			ready : function() {
				console.log("READY");
			},
			scrimClick : function(){
				this.hidePopups();
				
				this.$.scrim.hide();
			},
			getScoreboardTplUrl : function() {
				var url = main.config.scoreboardUrls.template.PROD;
				if (env.currentEnv == env.QA) {
					url = main.config.scoreboardUrls.template.QA;
				}
				return url;
			},
			
			createOnce : function() {
				if (!this.created) {

					var that = this, d = new Date();
					if (this.date == null) {
						this.date = bam.datetime.DateTime(d).setTimeZone(-5,
								bam.datetime.isDST(d));
					}

					/*
					 * main.$.sliding.$.middleCanonView.$.title.createComponent( {
					 * name : "scoreboardHeader", kind : mlb.ScoreboardHeader
					 * });
					 * main.$.sliding.$.middleCanonView.$.title.$.scoreboardHeader.$.gameDate
					 * .setContent(this.getDateString());
					 */

					// init scoreboard
					var masterScoreboard   = jQuery.pollable(new bam.services.MasterScoreboard()),
						miniScoreboardView = jQuery.template( this.getScoreboardTplUrl() ), 
						today              = bam.datetime.toShortDate( bam.datetime.DateTime(d).setTimeZone( -5, bam.datetime.isDST(d) ) ),
						scoreboard         = this.$.scoreboard, 
						gameday            = this.$.gameday, 
						gamedayChrome      = this.$.gamedayChrome, 
						audio              = this.$.audio, 
						audioChrome        = this.$.audioChrome;

					masterScoreboard
							.onLoadBeforeSend(function(event, data) {
								console.log("Load Before Send");
								isLoading = true;
								scoreboard.addClass("blur");
								if(main.currentMiddlePane=="Scoreboard"){
									main.showMiddleSpinner();
								}
							})
							.onLoadError(function(event, data) {
								console.log("Load Error");
								scoreboard.setContent("");
								scoreboard.removeClass("blur");
								isLoading = false;
								main.hideMiddleSpinner();
							})
							.onLoadSuccess(
									function(event, data) {
										console.log("Load Success");
										var d = new Date(data.date), p = new Date(
												d), n = new Date(d), m = d
												.getMonth() + 1, day = d
												.getDate(), longDay = d
												.getDay() + 1, y = d
												.getFullYear(), longDate = bam.datetime
												.getDayFullName(longDay)
												+ ", "
												+ bam.datetime
														.getMonthFullName(m)
												+ " " + day + ", " + y, shortDate = bam.datetime
												.getMonthName(m)
												+ " " + day + ", " + y;

										p.setDate(p.getDate() - 1);
										n.setDate(n.getDate() + 1);

										var formattedP = bam.datetime
												.toShortDate(p), formattedN = bam.datetime
												.toShortDate(n);

										var tpl_results = miniScoreboardView(
												data, true)

										scoreboard.setContent(tpl_results);
										// enyo.byId(scoreboard.id).innerHTML=tpl_results;
										scoreboard.removeClass("blur");
										main.hideMiddleSpinner();
										isLoading = false;
										isCreated = true;
									});

					jQuery("#fullScoreboard>li")
							.live(
									"click",
									function(e) {
										if (jQuery(this).hasClass("nogames")) {
											return false;
										}
										if (isLoading || displayGameDayModal
												|| displayAudioModal) {
											if (displayGameDayModal) {
												onGamedayHide();
											}
											;
											if (displayAudioModal) {
												onAudioHide();
											}
											;
											return false;
										}
										var anchor = $(this).find("a"), gid = anchor
												.attr("name"), state = $(this)
												.find("div.game_ind").text();
										
										var leftPos = (jQuery("#" + that.$.scroller.id).width() > 1000) ? 280
												: 400;
										var topPos = (jQuery("#" + that.$.scroller.id).height() / 2 - 310) + 54;
										// 310 = height of popup/2
										// 54 = height of header

										masterScoreboard.stop('load');
										scoreboard.addClass("blur");
										that.$.scrim.show();
										displayGameDayModal = true;
										that.isPopupDisplayed = true;
										gameday.openAt( {
											top : topPos,
											left : leftPos
										});
										that.setGame(gid, state);

										Track("GameDay_Popup");
										return false;
									});
					jQuery("#scoreboardView_innerClient")
							.live(
									"click",
									function(e) {
										if (displayGameDayModal
												&& e.target.id == "scoreboardView_innerClient" // avoid
												// closing
										// popup
										// when
										// gameday
										// content
										// is
										// clicked
										) {
											onGamedayHide();
										}
										if (displayAudioModal
												&& e.target.id == "scoreboardView_innerClient" // avoid
												// closing
										// popup
										// when
										// gameday
										// content
										// is
										// clicked
										) {
											onAudioHide();
										}
									});

					function onGamedayHide() {
						scoreboard.removeClass("blur");
						gameday.close();
						//main.$.sliding.$.middleCanonView.$.title.setContent("");
						that.$.scoreboardHeader.render();
						displayGameDayModal = false;
						that.isPopupDisplayed = false;
						that.$.scoreboardHeader.$.gamedayAudioButton.show();
						that.$.scoreboardHeader.$.DateNav.show();
						masterScoreboard.start('load', 15000, [ that.date ], true);
					}
					function onAudioHide() {
						scoreboard.removeClass("blur");
						audio.close();
						displayAudioModal = false;
						that.isPopupDisplayed = false;
						masterScoreboard.start('load', 15000, [ that.date ], true);
					}

					function getConfigDates() {
						return {
							"firstAllowedDay" : new Date(
									main.config.firstAllowedDay[0],
									main.config.firstAllowedDay[1] - 1,
									main.config.firstAllowedDay[2]),
							"lastAllowedDay" : new Date(
									main.config.lastAllowedDay[0],
									main.config.lastAllowedDay[1] - 1,
									main.config.lastAllowedDay[2]),
							"suggestedDay" : new Date(
									main.config.suggestedDay[0],
									main.config.suggestedDay[1] - 1,
									main.config.suggestedDay[2]),
							"openingDay" : new Date(main.config.openingDay[0],
									main.config.openingDay[1] - 1,
									main.config.openingDay[2])
						};
					}
					function isSameDay(a, b) {
						if (a.getFullYear() == b.getFullYear()
								&& a.getMonth() == b.getMonth()
								&& a.getDate() == b.getDate()) {
							return true;
						} else {
							return false;
						}
					}

					this.configDates = getConfigDates();

					this.hidePopups = function() {
						onGamedayHide();
						onAudioHide();
					};

					// grab the hash to pass masterScoreboard
					changeScoreboardDate = function(date) {
						console.log("change date");
						console.log(date);
						if (!date) {
							var d = new Date(), 
								today = bam.datetime.DateTime(d).setTimeZone(-5,bam.datetime.isDST(d));
							date = (
									that.configDates != null 
									&& that.configDates.suggestedDay.getTime() > today.getTime()
								) ? that.configDates.suggestedDay : today;
							if (date.getHours() < 10) {
								date.setDate(date.getDate() - 1);
							}
						}

						if (that.configDates != null) {
							if (date.getTime() < that.configDates.firstAllowedDay.getTime()) {
								date = bam.datetime.clone(that.configDates.firstAllowedDay);
							}
							if (date.getTime() > that.configDates.lastAllowedDay.getTime()) {
								date = bam.datetime.clone(that.configDates.lastAllowedDay);
							}
						}

						that.date = date;
						masterScoreboard.stop('load');
						masterScoreboard.start('load', 15000, [ date ], true);
						
						that.$.scoreboardHeader.$.gameDate.setContent(that.getDateString());
						that.$.scoreboardHeader.gameDate = date;
						/*
						 * main.$.sliding.$.middleCanonView.$.title.$.scoreboardHeader.$.gameDate
						 * .setContent(that.getDateString());
						 * main.$.sliding.$.middleCanonView.$.title.$.scoreboardHeader.gameDate =
						 * date;
						 */
						// used
						// in
						// date
						// picker
						that.$.scroller.scrollTo(0, 0);
					};

					showGameDayAudio = function() {
						var leftPos = (jQuery("#" + that.$.scroller.id).width() > 1000) ? 280 : 400, 
							topPos = (jQuery("#" + that.$.scroller.id).height() / 2 - 310) + 54; // 310
						// =
						// height
						// of
						// popup/2,
						// 54 =
						// height
						// of
						// header
						masterScoreboard.stop('load');
						scoreboard.addClass("blur");
						that.$.scoreboardHeader.$.gamedayAudioButton.hide();
						that.$.scoreboardHeader.$.DateNav.hide();
						that.$.scrim.show();
						displayAudioModal = true;
						that.isPopupDisplayed = true;
						/*left = (main.$.sliding.$.middleCanonView.getOffset().left > 199) ? 400
								: 280;*/
						audio.openAt( {
							top : topPos,
							left : leftPos
						});
						Views.Audio
								.renderInto(enyo.byId(that.$.audioChrome.id));
						Track("GameDayAudio_Popup");
					};

					this.created = true;
				}
			},
			create : function() {
				console.log("************ ScorebaordView create Called!");
				var that = this, d = new Date();
				this.inherited(arguments);

			},
			show : function() {
				this.createOnce();
				changeScoreboardDate();
			},
			getDateString : function() {
				var date = (arguments.length > 0) ? arguments[0] : this.date;
				return Months[date.getMonth()] + " " + date.getDate() + ", "
						+ date.getFullYear();
			}
		});

enyo
		.kind( {
			name : "mlb.ScoreboardHeader",
			kind : "Header",
			// className : "header",
			published : {
				gameDate : null
			},
			components : [ {
				kind : enyo.HFlexBox,
				flex : 1,
				components : [ {
					kind : "CustomButton",
					className : "gamedayAudio",
					name : "gamedayAudioButton",
					onclick : "gameDayAudioClick",
					onmousedown : "mouseDownHandler",
					onmouseup : "mouseUpHandler",
					components : [ {
						kind : "Image",
						src : "imgs/icons/audio.png"
					} ]
				} ]
			}, {
				name : "DateNav",
				flex : 1,
				layoutKind : "HFlexLayout",
				components : [ {
					kind : "CustomButton",
					className : "calendar",
					onclick : "calendarButtonClick",
					components : [ {
						kind : "Image",
						src : "imgs/icons/calendar_26x25.png"
					} ]
				}, {
					kind : "CustomButton",
					onclick : "previousButtonClick",
					className : "prevButton",
					components : [ {
						kind : "Image",
						src : "imgs/previous.png"
					} ]
				}, {
					name : "gameDate",
					className : "gameDate"
				}, {
					kind : "CustomButton",
					onclick : "nextButtonClick",
					className : "nextButton",
					components : [ {
						kind : "Image",
						src : "imgs/next.png"
					} ]
				}, {
					kind : "Popup",
					name : "Calendar",
					components : [ {
						kind : "DatePicker",
						label : "Select Game Date",
						onChange : "calendarChange"
					}, {
						kind : "Button",
						caption : "OK",
						onclick : "selectDate"
					}, {
						kind : "Button",
						caption : "Back To Today",
						onclick : "selectToday"
					} ]
				} ]
			}, {
				kind : enyo.HFlexBox,
				flex : 1,
				name : "spacer"
			} ],
			previousButtonClick : function() {
				if (isLoading) {
					return false;
				}
				var currentDate = new Date(this.$.gameDate.getContent()), 
					newDate = bam.datetime.clone(currentDate);
				newDate.setDate(currentDate.getDate() - 1);
				this.gameDate = newDate;
				changeScoreboardDate(newDate);
			},
			nextButtonClick : function() {
				if (isLoading) {
					return false;
				}
				var currentDate = new Date(this.$.gameDate.getContent()), 
					newDate = bam.datetime.clone(currentDate);
				newDate.setDate(currentDate.getDate() + 1);
				this.gameDate = newDate;
				changeScoreboardDate(newDate);
			},
			calendarButtonClick : function(sender) {
				this.$.Calendar.openAtControl(sender);
				if (this.gameDate) {
					this.$.datePicker.setValue(this.gameDate);
				}
			},
			calendarChange : function() {
				this.gameDate = this.$.datePicker.getValue();
			},
			selectDate : function() {
				this.$.Calendar.close();
				changeScoreboardDate(this.gameDate);
			},
			selectToday : function() {
				var d = new Date(), newDate = bam.datetime.DateTime(d)
						.setTimeZone(-5, bam.datetime.isDST(d));
				this.$.Calendar.close();
				changeScoreboardDate(newDate);
				this.gameDate = newDate;
			},
			gameDayAudioClick : function() {
				showGameDayAudio();
			},
			mouseDownHandler : function(inSender) {

			},
			mouseUpHandler : function(inSender) {

			}
		});