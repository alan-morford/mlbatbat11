enyo
		.kind( {
			name : "mlb.StandingsView",
			kind : "enyo.VFlexBox",

			published : {
				date : null
			},
			components : [
			{
				kind: "enyo.ApplicationEvents",
				name: "appEvents",
				onWindowActivated:"windowActivated"
			},
			{
				name : "standingsViewHeader",
				kind : "mlb.StandingsViewHeader",
				flex : 0
			}, {
				kind : "VFlexBox",
				flex : 1,
				components : [ {
					flex : 1,
					name : "webview",
					kind : "WebView",
					url : "http://wap.mlb.com/atbat/palm/standings/",
					height : "620px",
					minFontSize : "0",
					// style:"height:100%",
					onLoadStarted : "loadStarted",
					onLoadComplete : "loadComplete"
				} ]
			},

			{
				kind : "Toolbar",
				height : "40px",
				flex : 0,
				components : [ {
					kind : "GrabButton"
				} ]
			}

			],

			show : function() {
				
				//print(this.$.webview);
				var standingsViewHeader = this.$.standingsViewHeader;
				var _self = this;

				standingsViewHeader.buttonClicked = function(name) {
					if (name == "divisionalButton") {
						_self.$.webview
								.setUrl("http://wap.mlb.com/atbat/palm/standings/");
					} else if (name == "wildcardButton") {
						_self.$.webview
								.setUrl("http://wap.mlb.com/atbat/palm/standings/?t=wc");
					}
				};

			},
			loadStarted : function() {
				main.showMiddleSpinner();
			},
			loadComplete : function() {
				main.hideMiddleSpinner();
			},
			
			windowActivated: function() {
				console.log("REFRESH WEBVIEW");
				this.$.webview.setUrl(this.$.webview.getUrl());
			}

		});

enyo
		.kind( {
			name : "mlb.StandingsViewHeader",
			kind : "Header",
			// className : "header",
			// layoutKind: "HFlexLayout",
			published : {
				buttonClicked : function(name) {
				}
			},
			components : [
					{
						kind : enyo.HFlexBox,
						flex : 1,
						name : "spacer"
					},
					{
						kind : "RadioToolButtonGroup",
						// style: "width:200px; height:32px; margin-top : 10px",
						flex : 1,
						components : [
								{
									name : "divisionalButton",
									caption : "Divisional",
									className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-first",
									onclick : "clicked"

								},
								{
									name : "wildcardButton",
									caption : "Wild Card",
									className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-last",
									onclick : "clicked"
								}

						]
					}, {
						kind : enyo.HFlexBox,
						flex : 1,
						name : "spacer"
					} ],

			clicked : function(sender) {
				this.buttonClicked(sender.name);
			}
		});
