enyo
		.kind( {
			name : "mlb.ArticleListItem",
			kind : enyo.HFlexBox,
			className : "articleListItem",
			published : {
				articleData : null,
				index : -1
			},
			onclick : "itemclick",

			components : [
					{
						style : "padding:4px; background:rgba(0,0,0,0.3); width:98px; height:74px; margin-right: 20px",
						components : [ {
							style : "background:#fff url(imgs/default_thumb.png) no-repeat center 3px;height:72px;",
							components : [ {
								name : "articleImage",
								kind : "Image",
								className : "articleListItemImage",
								style : "width:96px; height: 72px; border: 1px solid white;",
								src : ""
							} ]
						} ]
					}, {
						flex : 1,
						components : [ {
							className : "articleListItemTitle",
							name : "articleTitle",
							nodeTag : "div"
						}, {
							name : "articleBlurb",
							allowHtml : true,
							className : "articleListItemBlurb",
							nodeTag : "div"
						} ]
					} ]

		});

enyo
		.kind( {
			name : "mlb.NewsViewHeader",
			kind : "Toolbar",
			style : "height:40px",
			published : {
				buttonClicked : function(name) {
				}
			},
			components : [
					{
						kind : "Popup",
						name : "chooseTeamPopup",
						showHideMode : "auto",
						dismissWithClick : true,
						style : "width:100px; height:700px; padding:0",
						components : [ {
							flex : 1,
							style : "width:100%; height:100%",
							name : "teamList",
							kind : "mlb.MLBTeamListView"
						} ]
					},
					{
						kind : "Button",
						name : "chooseTeam",
						caption : "MLB",
						onclick : "chooseTeamClicked",
						style : "width:200px;",
						className: "enyo-button-dark"
							
					},
					{

						kind : "RadioToolButtonGroup",
						style : "height:32px",
						showing : false,
						components : [
								{
									name : "mlbButton",
									caption : "MLB",
									className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-first",
									onclick : "clicked"
								},
								{
									name : "teamButton",
									caption : "Team",
									className : "enyo-radiobutton-dark enyo-grouped-toolbutton-dark enyo-first",
									onclick : "clicked"
								}

						]
					} ],

			clicked : function(sender) {

				this.buttonClicked(sender.name);
			},
			chooseTeamClicked : function(sender) {

				this.$.chooseTeamPopup.openAtControl(sender, {
					top : -10,
					left : -10
				});
			}

		});

enyo.kind( {
	name : "mlb.FullArticleViewHeader",
	kind : "Toolbar",
	style : "height:40px",
	flex : 1,
	published : {
		leftButtonClicked : null,
		rightButtonClicked : null
	},
	components : [

	{
		kind : "CustomButton",
		name : "left",
		className : "prevButton",
		onclick : "leftClicked",
		components : [ {
			kind : "Image",
			src : "imgs/previous.png"
		} ]
	}, {
		kind : "CustomButton",
		name : "text",
		className : "gameDate",
		content : "1 of 10"
	}, {
		kind : "CustomButton",
		name : "right",
		className : "nextButton",
		onclick : "rightClicked",
		components : [ {
			kind : "Image",
			src : "imgs/next.png"
		} ]
	} ],
	leftClicked : function() {

		if (this.leftButtonClicked) {
			this.leftButtonClicked();
		}

	},
	rightClicked : function() {
		if (this.rightButtonClicked) {
			this.rightButtonClicked();
		}
	}

});

enyo
		.kind( {
			name : "mlb.FullArticleView",
			className : "fullArticleView",
			kind : enyo.VFlexBox,
			flex:1, 
			style : "background-color:#E7E7DB;",

			published : {
				articleList : null,
				articleIndex : -1,
				header : null
			},
			components : [
					{
						name : "getArticle",
						kind : "NewsArticleService",
						onSuccess : "gotArticle"

					},

					{
						kind : "Scroller",
						name : "articleScroller",
						flex : 1,
						components : [

								{
									kind : "enyo.VFlexBox",
									components : [ {
										className : "articleTitle",
										name : "articleTitle",
										allowHtml : true
									}, {
										className : "articleKicker",
										name : "articleKicker",
										allowHtml : true
									}, {
										className : "articleByLine",
										name : "articleByLine",
										allowHtml : true
									} ]
								},
								{

									components : [
											{
												name : "articleImageWrapper",
												className : "articleImageWrapper",
												style : "float:right; margin-left:10px; margin-bottom:20px; width:100%; max-width:420px; position:relative; border-bottom:2px solid #A6A698",
												onclick : "articleMediaClick",
												components : [
														{

															name : "articleImage",
															className : "articleImage",
															kind : "Image",
															style : "max-width:420px; width:97%;"

														},
														{
															name : "playImage",
															kind : "Image",
															style : "position:absolute; top: 0; left: 0",
															src : "imgs/play-button.png"
														},
														{
															className : "videoTitle",
															name : "videoTitle",
															style : "font-weight:bold; font-size:85%; margin-bottom: 5px",
															allowHtml : true
														},
														{
															className : "videoKicker",
															name : "videoKicker",
															style : "font-size:85%; line-height:100%; margin-bottom:5px",
															allowHtml : true
														}

												]
											}, {
												className : "articleBody",
												name : "articleBody",
												allowHtml : true,
												flex:1
											} ]
								} ]
					}

			],

			rendered : function() {

				// this.$.articleImage.setAttribute("align", "right");
				if (Views && Views["News"]) {
					header = Views["News"].$.fullArticleViewHeader;

					var _self = this;
					header.rightButtonClicked = function() {
						if (_self.articleIndex < _self.articleList.length - 1) {
							_self.articleIndex++;
							//_self.showArticle();
							Views["News"].showArticle(_self.articleIndex, _self.articleList);
						}

					};
					header.leftButtonClicked = function() {
						if (_self.articleIndex > 0) {
							_self.articleIndex--;
							Views["News"].showArticle(_self.articleIndex, _self.articleList);
						}
					};

					/*(header)
							.renderInto(document
									.getElementById(main.$.sliding.$.rightCanonView.$.title.id));*/
					_self.showArticle();
				}

			},
			showArticle : function() {

				this.$.articleScroller.scrollTo(0, 0);
				var articleData = this.articleList[this.articleIndex];
				var articleCid = articleData.cid;
				this.$.articleTitle.setContent(articleData.title);
				// this.$.articleKicker.setContent(articleData.kicker);
				this.$.getArticle.urlParams = {
					"yyyy" : articleCid.substring(0, 4),
					"mm" : articleCid.substring(4, 6),
					"dd" : articleCid.substring(6, 8),
					"id" : articleCid.substring(8)
				};

				
				header.$.text.setContent((this.articleIndex + 1) + " of "
						+ this.articleList.length);
				this.$.articleBody.setContent("");

				this.$.getArticle.call();
			},

			gotArticle : function(inSender, inResponse, inRequest) {
				

				var articleData = XMLJSONConverter.convert(inResponse);

				this.$.articleBody.setContent(articleData.item.body);

				// var date = Date.parse(articleData.item.releasedate);

				var date = bam.datetime.parseXMLDate(articleData.item.releasedate + "Z");
				
				
				date.setTimeZone(-5, date.isDST());
				
				// alert( articleData.item.releasedate);
				this.$.articleByLine.setContent(articleData.item.byline + " | "
						+ date.formatDate("EEEE, MMMM dd, yyyy h:mm A") + " ET");
				
				var relatedMedia = this.findRelatedMedia(articleData);

				this.$.articleKicker.setContent(articleData.item.subhead);

				if (relatedMedia && relatedMedia.image) {
					this.$.articleImageWrapper.relatedMedia = relatedMedia;
					this.$.articleImage.setSrc(relatedMedia.image.url);
					this.$.videoTitle.setContent(relatedMedia.title);
					this.$.videoKicker.setContent(relatedMedia.kicker);
					this.$.articleImageWrapper.show();
				} else {

					this.$.articleImageWrapper.hide();
				}
				
				
				Views["News"].$.articlePane.selectViewByName(this.name);

			},

			findRelatedMedia : function(articleData) {
				var media = null;
				var children = Util.array(articleData.item.children.item);
				var url = "";
				for ( var i = 0; i < children.length; i++) {
					if (children[i].defkey == "related-media") {

						if (!children[i] || !children[i].members
								|| !children[i].members.item) {
							continue;
						}
						var member = Util.array(children[i].members.item)[0];

						if (!member.transcodes || !member.transcodes.transcode) {
							continue;
						}

						var transcodes = Util
								.array(member.transcodes.transcode);

						for ( var t = 0; t < transcodes.length; t++) {
							var transcode = transcodes[t];

							if (transcode.speed == "1200") {

								media = {};
								media.title = member.headline;
								media.kicker = member.bigblurb;
								media.url = transcode.w;
								break;
							}
						}

						var images = Util.array(member.children.item);
						for ( var j = 0; media && j < images.length; j++) {
							if (images[j].type == "images"
									&& parseInt(images[j].width) == "480") {

								media.image = {
									url : images[j].url,
									width : parseInt(images[j].width),
									height : parseInt(images[j].height)
								};
								break;
							}
						}
					}

				}
				return media;

			},

			findImage : function(articleData) {
				var children = Util.array(articleData.item.children.item);
				var url = "";
				for ( var i = 0; i < children.length; i++) {
					if (children[i].type == "images"
							&& parseInt(children[i].width) >= 400) {
						return {
							url : "http://mlb.mlb.com" + children[i].url,
							width : parseInt(parseInt(children[i].width)),
							height : parseInt(parseInt(children[i].height))
						};
					} else if (children[i].defkey == "related-media") {
						var member = Util.array(children[i].members.item)[0];
						var images = Util.array(member.children.item);
						for ( var j = 0; j < images.length; j++) {
							if (images[j].type == "images"
									&& parseInt(images[j].width) >= 400) {
								return {
									url : images[j].url,
									width : parseInt(images[j].width),
									height : parseInt(images[j].height)
								};
							}
						}

					}
				}
				return null;
			},
			articleMediaClick : function() {
				main.launchVideo(this.$.articleImageWrapper.relatedMedia.url);
			}

		});

enyo.kind( {
	name : "mlb.TeamListItem",
	kind : "enyo.HFlexBox",
	published : {
		team : null
	}
});

enyo.kind( {
	name : "mlb.MLBTeamListView",
	kind : "enyo.VFlexBox",
	flex : 1,
	create : function() {
		this.teams = [];
		this.inherited(arguments);
	},
	components : [ {
		kind : "VirtualList",
		className : "teamList",
		flex : 1,
		name : "teamList",
		onSetupRow : "listSetupRow",
		components : [ {
			name : "teamListItem",
			kind : "mlb.TeamListItem",
			className : "teamListItem",
			onclick : "listItemClick"

		} ]
	}, {
		name : "getNews",
		kind : "NewsArticlesService",
		onSuccess : "gotNews"
	} ],

	rendered : function() {
		this.node = enyo.byId(this.id);
		this.inherited(arguments);
		// this.childrenRendered();
		main.showMiddleSpinner();

		this.teams = [];
		for ( var i in clubProps) {
			this.teams.push(clubProps[i]);
		}

		this.teams = this.teams.sort(function(a, b) {
			if (b.club_full_name == "MLB") {
				return 1;
			}
			if (a.club_full_name == "MLB") {
				return -1;
			}

			var A = a.club_full_name.toLowerCase(), B = b.club_full_name
					.toLowerCase();
			if (A < B) {
				return -1;
			} else if (A > B) {
				return 1;
			} else {
				return 0;
			}
		});

		this.$.teamList.refresh();
	},

	listSetupRow : function(inSender, inIndex) {

		if (inIndex >= 0 && inIndex < this.teams.length) {
			this.$.teamListItem.team = this.teams[inIndex];
			this.$.teamListItem.index = inIndex;
			this.$.teamListItem.setContent(this.teams[inIndex].club_full_name);
			return true;
		}
		return false;
	},
	listItemClick : function(item) {
		Views["News"].showArticleList(item.team);
		//print(this.parent);
	this.parent.close();
},
gotNews : function(inSender, inResponse, inRequest) {

	main.hideMiddleSpinner();

	var articles = XMLJSONConverter.convert(inResponse).data.item;

	Views["News"].showArticle(0, articles);

}
});

enyo.kind( {
	name : "mlb.MLBNewsView",

	className : "newsView",
	kind : enyo.VFlexBox,
	flex : 1,
	style : "background-color:#E7E7DB",
	create : function() {
		this.articles = [];
		this.inherited(arguments);
	},

	components : [ {
		kind : "VirtualList",
		className : "newsList",
		flex : 1,
		name : "newsList",
		onSetupRow : "listSetupRow",
		components : [ {
			kind : "mlb.ArticleListItem",
			onclick : "ArticleListItemClick"
		} ]
	}, {
		name : "getNews",
		kind : "NewsArticlesService",
		onSuccess : "gotNews"
	} ],
	listSetupRow : function(inSender, inIndex) {

		if (inIndex >= 0 && inIndex < this.articles.length) {
			var listArticleItemData = this.articles[inIndex];
			var pictures = Util.array(listArticleItemData.pictures.picture);
			if (pictures && pictures.length > 0) {
				this.$.articleListItem.$.articleImage
						.setSrc("http://mlb.mlb.com" + pictures[0].url);
			}
			this.$.articleListItem.$.articleTitle
					.setContent(listArticleItemData.title);
			this.$.articleListItem.index = inIndex;

			this.$.articleListItem.$.articleBlurb
					.setContent(listArticleItemData.description);
			this.$.articleListItem.articleData = listArticleItemData;
			

			return true;
		}
		return false;
	},

	ArticleListItemClick : function(item) {

		Views["News"].showArticle(item.index, this.articles);
	},

	rendered : function() {

		this.node = enyo.byId(this.id);
		this.inherited(arguments);


		//this.$.getNews.call();
	this.getArticles("mlb");

},
gotNews : function(inSender, inResponse, inRequest) {
	console.log("******GOTNEWS******");

	main.hideMiddleSpinner();

	this.articles = XMLJSONConverter.convert(inResponse).data.item;

	this.$.newsList.refresh();
	
	Views["News"].showArticle(-1, this.articles);
	
	
},
refresh: function() {
	main.showMiddleSpinner();
	this.$.getNews.call();
},
getArticles : function(club) {
	main.showMiddleSpinner();
	this.$.getNews.urlParams = {
		"teamcode" : club
	};
	this.$.getNews.call();
}
});

enyo.kind( {
	name : "mlb.NewsView",
	className : "newsView",
	kind : enyo.VFlexBox,

	style : "background-color:#E7E7DB",
	create : function() {
		this.articles = [];
		this.currentlySelectedArticlePane = 0;
		this.inherited(arguments);
	},
	components : [ {
		kind: "enyo.ApplicationEvents",
		name: "appEvents",
		onWindowActivated:"windowActivated"
	},
	               {
		name : "slidingPane",
		kind : "SlidingPane",
		flex : 1,
		onSelectView : "slidingSelected",
		components : [ {
			width : "400px",
			components : [ {
				name : "newsViewHeader",
				kind : "mlb.NewsViewHeader"

			}, {
				kind : "Pane",
				name : "panes",
				flex : 1,
				transitionKind : "enyo.transitions.Fade",
				components : [ {
					kind : "mlb.MLBNewsView",
					name : "articleList"
				}, {
					kind : "mlb.MLBTeamListView"
				}

				]
			}, {
				kind : "Toolbar"
			/*
			 * components : [ { kind : "GrabButton" } ]
			 */
			} ]
		},

		{
			onResize : "fullArticleResize",
			components : [ {
				name : "fullArticleViewHeader",
				kind : "mlb.FullArticleViewHeader",
				flex : 0
			}, 
			
			{
				kind : "Pane",
				name : "articlePane",
				flex : 1,
				transitionKind : "enyo.transitions.Fade",
				components : [ 			{
					name : "fullArticleView0",
					kind : "mlb.FullArticleView",
					flex : 1
				}, 
				{
					name : "fullArticleView1",
					kind : "mlb.FullArticleView",
					flex : 1
				}

				]
			}
			, 
			{
				kind : "Toolbar",
				height : "40px",
				components : [ {
					kind : "GrabButton"
				} ]
			} ]

		} ]
	} ],

	create:function() {
		this.inherited(arguments);
		this.currentArticleIndex=0;
	},
	show : function() {

		this.node = enyo.byId(this.id);
		this.inherited(arguments);
		
		//print(this.$.appEvents);

		var _self = this;
		// _self.$.panes.selectViewByIndex(0);
		this.$.newsViewHeader.buttonClicked = function(name) {
	
			if (name == "mlbButton") {
	
				_self.$.panes.selectViewByIndex(0);
			} else if (name == "teamButton") {
	
				_self.$.panes.selectViewByIndex(1);
	
			}
		};

	},

windowActivated: function() {
	//console.log("WINDOW ACTIVATED!!!!!!!!!");
	if(this.$.articleList) {
		this.$.articleList.refresh();
	}
},

fullArticleResize : function() {
	//this.$.fullArticleView.$.articleScroller.scrollTo(0, 0);
	if(this.$["fullArticleView"+this.currentlySelectedArticlePane]){
		this.$["fullArticleView"+this.currentlySelectedArticlePane].$.articleScroller.scrollTo(0,0);
	}

},

showArticle : function(articleIndex, articleList) {
	//alert("News VIewSHOW ARTICLE");
	if(this.currentlySelectedArticlePane==0) {
		this.currentlySelectedArticlePane =1 ;
	}
	else {
		this.currentlySelectedArticlePane =0;
	}
	
	
	if(articleIndex == -1) {
		articleIndex = this.currentArticleIndex;
	}
	
	this.currentArticleIndex = articleIndex;
	
	this.$["fullArticleView"+this.currentlySelectedArticlePane].articleList = articleList;
	this.$["fullArticleView"+this.currentlySelectedArticlePane].articleIndex = articleIndex;
	this.$["fullArticleView"+this.currentlySelectedArticlePane].render();
	

	
},
showArticleList : function(team) {
	//alert("SHOW ARTICLE LIST");
	this.currentArticleIndex=0;
	this.$.newsViewHeader.$.chooseTeam.setCaption(team.club_full_name);
	this.$.articleList.getArticles(team.club);
}

});
