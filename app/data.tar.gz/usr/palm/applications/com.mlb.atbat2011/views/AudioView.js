enyo
		.kind( {
			name : "mlb.AudioItem",
			kind : enyo.HFlexBox,
			published : {
				audioData : null,
				game : null
			},
			components : [ {
				name : "gameTitle",

				style : "width:70%"

			}, {
				name : "gameStatus",
				style : "width:30%; text-align:right"
			}

			],
			style : "height: 40px; padding: 10px; border-top: 1px solid #666; border-bottom: 1px solid black",
			rendered : function() {

				this.inherited(arguments);
				this.childrenRendered();

			}
		});

enyo
		.kind( {
			name : "mlb.AudioView",
			kind : enyo.VFlexBox,
			flex : 1,

			style : "margin-left:5px; margin-top: 5px; color: white; width: 421px; background-color:#2B2B2A; border-top-left-radius: 5px; border-top-right-radius:5px; -webkit-box-shadow: 0px 0px 5px #000; ",
			published : {
				date : null,
				currentlySelectedFeedButton : null,
				timeoutId:null
			},
			components : [
					{
						name : "buttonAndStatusBox",
						kind : enyo.HFlexBox,
						style : "padding: 20px; height:103px; background-image: url(imgs/audio/hp_scoreboard_audio_base.png);  border-top-left-radius: 5px; border-top-right-radius:5px;",
						components : [
								{
									kind : "CustomButton",
									name : "actionButton",
									onclick : "actionButtonClick",
									value: "play",
									style : "height: 54px; width: 61px; padding:0; margin-right: 10px; background-image: url(imgs/audio/btn_play.png);"
								},
				
								{
									kind : "Scroller",
									name : "statusBox",
									style : "height: 45px; margin-left:4px; margin-top:5px; width:305px",
									components : [
											{
												name : "status",
												content : ""
												//style:"overflow: scroll"
											},
											{
												name : "feedName",
												content : "",
												style : "font-weight:bold; padding-top:5px"

											} ]
								}

						]

					},
					/*{
						kind: "ProgressSlider", 
						name: "volumeSlider",
						style: "width: 80%; height: 40px,",
					 	onChanging: "volumeSliderChanging", onChange: "volumeSliderChange"
					},*/
					{
						kind : "Toolbar",
						name: "buttonToolbar",
						style : "width:100%; height:40px;",
						showing: false,
						components : [ 
						               
						               {
							name : "feedList",
							kind : "RadioToolButtonGroup",
							style : "height:40px; width: 90%;",

							components : [
							              
							              

							{
								name : "feed1",
								value: "feed1",
								caption: "feed1",
								onclick : "feedClicked",
								allowHtml : true,
								style:"font-size:100%; width:80px;"
							
							
							}, {
								name : "feed2",
								value: "feed2",
								caption: "feed2",
								onclick : "feedClicked",
								allowHtml : true,
								style:"font-size:100%; width:80px"
							}, {
								name : "feed3",
								value: "feed3",
								caption: "feed3",
								onclick : "feedClicked",
								allowHtml : true,
								style:"font-size:100%; width:80px"
							}, {
								name : "feed4",
								value: "feed4",
								caption: "feed4",
								onclick : "feedClicked",
								allowHtml : true,
								style:"font-size:100%; width:80px"
							}
							]

						} ]
					},

					/*{
						name : "NoFeeds",
						content : "No feeds/games currently available.",
						style : "font-weight:bold; padding-top:10px; padding-left:20px; background-color: #222222; height: 30px"

					},*/
					{
						kind : "VirtualList",
						flex : 1,
						name : "list",
						onSetupRow : "listSetupRow",

						components : [ {
							kind : "mlb.AudioItem",
							onclick : "audioItemClick"
						} ]
					},

					{
						name : "scoreboardService",
						kind : "ScoreboardService",
						onSuccess : "scoreboardServiceReturn"
					}
			],
			create : function() {
				console.log("Create AudioView");
				this.games = [];
				this.inherited(arguments);

			},
			rendered : function() {
				this.node = enyo.byId(this.id);
				this.inherited(arguments);
				this.childrenRendered();

				this.fetchScoreboard();
				
				
				var _self = this;
				
				
				main.$.audioFlow.addFlowListener("audioView", function(message)  {
					_self.$.status.setContent( message.statusMessage);
					_self.$.feedName.setContent(message.feedName);
					
					if(message.status=="NotPlaying") {
						_self.$.actionButton.value="play";
						_self.$.actionButton.applyStyle("background-image",
						"url(imgs/audio/btn_play.png)");
					}
					else if(message.status=="NowPlaying") {
						_self.$.actionButton.value="pause";
						_self.$.actionButton.applyStyle("background-image",
						"url(imgs/audio/btn_pause.png)");
					}
					else if(message.status=="PlaybackError") {
						_self.$.actionButton.value="play";
						_self.$.actionButton.applyStyle("background-image",
						"url(imgs/audio/btn_pause.png)");
						
						_self.timeoutId= setTimeout(function() {
							_self.feedClicked(_self.currentlySelectedFeedButton);
						},1000);
					}
					else if(message.status=="PlaybackStopped") {
						_self.$.actionButton.value="play";
						_self.$.actionButton.applyStyle("background-image",
						"url(imgs/audio/btn_pause.png)");
						
					}
					else {
						_self.$.actionButton.value="play";
						_self.$.actionButton.applyStyle("background-image",
						"url(imgs/audio/btn_play.png)");
					}
					
				});

			},

			listSetupRow : function(inSender, inIndex) {
				
				if(this.games.length == 0 && inIndex==0) {
					this.$.audioItem.$.gameTitle
					.setContent("No games/feeds currently available");
					this.$.audioItem.$.game = null;
					return true;
				}
				
				if (inIndex >= 0 && inIndex < this.games.length) {

					var game = this.games[inIndex];

					
					this.$.audioItem.$.gameTitle
							.setContent(game.away_name_abbrev + " at "
									+ game.home_name_abbrev);

					if(GameFlags.isAfterGameEnd(game)) {
						this.$.audioItem.$.gameStatus
						.setContent("Final");
					}
					else if(GameFlags.isBeforeGameStart(game)){
						this.$.audioItem.$.gameStatus
						.setContent("Pregame");
					}
					else if(GameFlags.isSuspended(game)){
						this.$.audioItem.$.gameStatus
						.setContent("Suspended");
					}
					else {
						this.$.audioItem.$.gameStatus
							.setContent((game.status.top_inning == "Y" ? "Top"
									: "Bot")
									+ " " + game.status.inning);
					}
					
					
					this.$.audioItem.game = game;

					if (inIndex == 0 && !main.$.audioFlow.feed) {
						console.log("*******THIS SHOULD ONLY GET CALLED ONCE*****");
						this.audioItemClick(this.$.audioItem);
					}
					else if(main.$.audioFlow.game && main.$.audioFlow.game.id==game.id) {
						console.log("*******************************, game selected:" + game.id +" ************");
						
						this.audioItemClick(this.$.audioItem);
						
					}

					return true;
				}
				return false;
			},

			scoreboardServiceReturn : function(inSender, inResponse, inRequest) {
				console.log("scoreboardServiceReturn");
				try {
					this.games = this.getGamesWithAudio(XMLJSONConverter
							.convert(inResponse).games.game);
					
	
					if (this.games.length == 0) {
						this.$.buttonToolbar.hide();
					}
					else {
						this.$.buttonToolbar.show();
					}

					this.$.list.refresh();
				}
				catch(e) {
					console.log(e);
				}
				
				_self = this;
				setTimeout(function() {
					console.log("FETCHING THE SCOREBOARD");
					_self.fetchScoreboard();
					
				}, 15000);
			},
			
			fetchScoreboard: function() {
				
				var date = new Date();
				date.setTime(date.getTime() - 1000*60*60*10);
				var dateFormat = new enyo.g11n.DateFmt("yyyyMMdd");
				var dateStr = dateFormat.format(date);

				this.$.scoreboardService.urlParams = {
											"yyyy" : dateStr.substring(0, 4),
											"mm" : dateStr.substring(4, 6),
											"dd" : dateStr.substring(6)
										};
				this.$.scoreboardService.call();
			},

			getGamesWithAudio : function(games) {

				var game;
				var gamesWithAudio = [];

				for ( var g = 0; g < games.length; g++) {
					game = games[g];
					if (game.audio) {
						var feeds = Util.array(game.audio.afeed);

						for ( var i = 0, k = 0; feeds && i < feeds.length; i++) {
							var feed = feeds[i];
							if (feed.playback_scenario == main.config.audioPlaybackScenarios.high
									&& feed.media_state == "MEDIA_ON") {
								gamesWithAudio.push(game);

								break;
							}
						}
					}
				}

				return gamesWithAudio;
			},

			actionButtonClick : function(button) {
				if (button.value == "pause") {
					main.$.audioFlow.pauseAudio();
				} 
				else if(main.$.audioFlow.feed) {
					main.$.audioFlow.startAudioFlow(main.$.audioFlow.feed,main.$.audioFlow.game);
				}
			},
			clearFeeds: function() {
				var controls = this.$.feedList.controls;
				for (var i=0, c; c=controls[i]; i++) {
					
					c.setDepressed(false);
					
				}
			},
			audioItemClick : function(audioItem) {

				
				this.clearFeeds();
				
				// set the feeds
				var game = audioItem.game;
				var feeds = Util.array(game.audio.afeed);
				var k;
				
				for ( var i = 0, k = 0; feeds && i < feeds.length; i++) {
					var feed = feeds[i];
					if (feed.playback_scenario == main.config.audioPlaybackScenarios.high
							&& feed.media_state == "MEDIA_ON") {

						this.setupFeedButton(this.$["feed" + (k + 1)],
								feed, game);

						k++;
					}
				}
				
				while (k < 4) {
					this.$["feed" + (k + 1)].hide();
					
					this.$["feed" + (k + 1)].feed=null;
					this.$["feed" + (k + 1)].game=null;
					
					k++;
				}

				if (!main.$.audioFlow.feed) {
					this.feedClicked(this.$["feed1"]);
				}
				
				this.$.feedList.render();

			},
			setupFeedButton : function(button, feed, game) {
				
				button.show();
				
				if(main.$.audioFlow.feed && (feed.content_id==main.$.audioFlow.feed.content_id)) {
					button.setDepressed(true);
				}
				button
						.setCaption((feed.perspective == "HOME" ? game.home_name_abbrev
								: game.away_name_abbrev)
								+ " "
								+ (feed.language == "EN" ? "" : " - "
										+ feed.language)
								+ " - "
								+ feed.station);
				button.feed = feed;
				button.game = game;
				

			},

			feedClicked : function(inSender) {
				if(this.timeoutId) {
					clearTimeout(this.timeoutId);
				}
				this.clearFeeds();
				
				if(inSender.feed) {
					this.currentlySelectedFeedButton= inSender;
					
					inSender.setDepressed(true);
					//this.$.feedList.setRadioDepressed(inSender.value);
				
					main.$.audioFlow.startAudioFlow(inSender.feed, inSender.game);
				}
			},
			volumeSliderChanging: function() {
				console.log("volume slider changing");
			},
			volumeSliderChange: function() {
				main.$.audioFlow.$.audioPlayer.audio.volume = 0;
				
				
				console.log("volume slider change");
			}
		});
